from myfunc import add

A = 10
B = 5
result = add(A, B)
print("ผลบวกของ A และ B คือ:", result)
